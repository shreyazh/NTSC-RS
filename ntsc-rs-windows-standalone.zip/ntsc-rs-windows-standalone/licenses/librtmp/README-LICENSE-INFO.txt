DISCLAIMER: THIS LICENSING INFORMATION IS PROVIDED ON A BEST-EFFORT BASIS
AND IS NOT MEANT TO BE LEGAL ADVICE. PLEASE TALK TO A LAWYER FOR ADVICE ON
SOFTWARE LICENSE COMPLIANCE.

The libraries and binaries in this package may be used under the terms of license file(s):

LGPL-2.1+.txt
(OR)
LICENSE-vcpkg-changes.txt